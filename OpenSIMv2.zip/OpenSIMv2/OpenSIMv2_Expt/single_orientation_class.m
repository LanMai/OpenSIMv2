classdef single_orientation_class
    
    properties
        PSFe = fspecial('gaussian',30,3.0); % for edgetapering      
           
        OTFo;
        %Snoisy;
        fSnoisy;
        
        Kotf;
        w;
        wo;
        Cv;
        Ro;
        G;
        
        %kAo;
        kAmean;
        kAmag;
        phaseA;
        Spattern;
        
        
        fDo;
        fDp;
        fDm;
        OBJpara;
        
        fDof;
        fDpf;
        fDmf;
        npDo;
        npDp;
        npDm;
        modFac
        
        ridgeWidth = 3; % pixels (half-width)
        Zridge;
        Zindex = false; % ( = true, if any of the illumination frequency peaks is close to X or Y axis)
        
        
        %% co = Noise to Signal Ratio; used during wiener-filtering of frequency components
        % (default value = 1.0, but may be changed if the user desires);
        co = 1.0;
        
        
        
        
    end
    
    methods
        
        function obj = single_orientation_class(Snoisy,OTFo,Kotf,PSFe)
            % constructor
            
            obj.OTFo = OTFo;
            obj.Kotf = Kotf;
            obj.PSFe =PSFe;
            obj.w = size(Snoisy,1); 
            obj.wo = obj.w/2;
            
            x = linspace(0,obj.w-1,obj.w);
            y = linspace(0,obj.w-1,obj.w);
            [X,Y] = meshgrid(x,y);
            obj.Cv = (X-obj.wo) + 1i*(Y-obj.wo);
            obj.Ro = abs(obj.Cv);
            if obj.Zindex
                obj.Zridge = ones(obj.w,obj.w);                
            else
                obj.Zridge = 1.*( abs(X-obj.wo)>obj.ridgeWidth ).*( abs(Y-obj.wo)>obj.ridgeWidth );
            end
            
            %% G is a notch-filter (determined heuristically)
            % for suppressing out-of-focus signal of off-center components 
            Rg = obj.Ro.*(512/obj.w);
            obj.G = 1 - exp(-0.05*Rg.^1.2);
            
            % edge tapering raw SIM images and FFT computation
            fSnoisy = zeros(size(Snoisy));
            for i = 1:3
                temp = edgetaper(Snoisy(:,:,i),obj.PSFe);
                fSnoisy(:,:,i) =  fftshift(fft2(temp));                
            end
            %obj.Snoisy = Snoisy;
            obj.fSnoisy = fSnoisy;
            clear temp Snoisy fSnoisy
            
        end
        %-------------------------------------------------------------------------------------
        
        
        function [fDo,fDp,fDm] = PCMseparateF(obj)
            %% unmixes the central and off-center frequecy components
            
            fS1noisy = obj.fSnoisy(:,:,1);
            fS2noisy = obj.fSnoisy(:,:,2);
            fS3noisy = obj.fSnoisy(:,:,3);
            
            phase = obj.phaseA;
            %% Separating the three frequency components
            MF = 1.0;
            %% Transformation Matrix
            M = 0.5*[1 0.5*MF*exp(-1i*phase(1)) 0.5*MF*exp(+1i*phase(1));
                1 0.5*MF*exp(-1i*phase(2)) 0.5*MF*exp(+1i*phase(2));
                1 0.5*MF*exp(-1i*phase(3)) 0.5*MF*exp(+1i*phase(3))];

            %% Separting the components
            %===========================================================
            Minv = inv(M);
            fDo = Minv(1,1)*fS1noisy + Minv(1,2)*fS2noisy + Minv(1,3)*fS3noisy;
            fDp = Minv(2,1)*fS1noisy + Minv(2,2)*fS2noisy + Minv(2,3)*fS3noisy;
            fDm = Minv(3,1)*fS1noisy + Minv(3,2)*fS2noisy + Minv(3,3)*fS3noisy;

            %% for visual verification
            %{
            figure;
            surf(log(abs(fDo)),'EdgeColor','none')
            colormap jet
            title('Central Freq-component')
            figure;
            surf(log(abs(fDp)),'EdgeColor','none')
            colormap jet
            title('off-center Freq-component-1')
            figure;
            surf(log(abs(fDm)),'EdgeColor','none')
            colormap jet
            title('off-center Freq-component-2')
            
            Do = real(ifft2(fftshift(fDo)));
            figure;
            imshow(Do,[])
            title('Wide-field component')
            %}
        end        
        %-------------------------------------------------------------------------------------
        
        
        function k2fa = peakCCidx(obj,fAo0,fAp0,Zmask)
            %% computes the cross-correlation (CC) between fAo0 and fAp0,
            % and then estimates the elative-shift-position producing
            % maximum value of CC
            
            Zo = double( obj.Ro<obj.Kotf );            
            
            Zn = fftshift( ifft2( fft2(Zo).*conj(fft2(Zo)) ) );
            CC = fftshift( ifft2( fft2(fAo0.*Zo).*conj(fft2(fAp0.*Zo)) ) );
            rho = abs(CC)./abs(Zn);
            %{
            figure, mesh(abs(Zn))
            figure, mesh(abs(CC))
            figure, mesh(rho.*Zmask)
            %kk
            %}            
            
            temp = rho.*Zmask;
            [~, v] = max(temp(:));
            
            pmax = mod(v-1,obj.w) + 1; % row
            qmax = (v-pmax)/obj.w + 1; % column
            px0 = qmax - (obj.wo+1);
            py0 = pmax - (obj.wo+1);
            k2fa = [py0 px0]; % nearest pixel approximation
            
        end
        %-------------------------------------------------------------------------------------
        
        
        function [kmean,kmag] =  kmeanF(obj)
            
            %% In the following, Illumination frequency (kA) is estimated 
            % for each of the 3 images and then averaged to obtain kmean
            %------------------------------------------- 
            %{
            kA = zeros(3,2);
            for i = 1:3
                fSa1Tnoisy = obj.fSnoisy(:,:,i);
                if i == 1
                    Zmask = 1.*(obj.Ro>0.75*obj.Kotf ).*(obj.Ro<1.1*obj.Kotf ); 
                    kAo = peakCCidx(obj,fSa1Tnoisy,fSa1Tnoisy,Zmask);
                end
                kA(i,:) = obj.IlluminationFreqTIRF(fSa1Tnoisy,fSa1Tnoisy,kAo);
            end
            %kA
            kmean = mean(kA,1);
            kmag = sqrt(kmean*kmean');
            %}
            %-------------------------------------------
            
            %% In most cases, estimating kA once and approximating "kmean = kA" suffices! 
            % one may use the following subroutine then:
            % (this reduces computational time!)
            %------------------------------------------- 
            %%{
            fSa1Tnoisy = obj.fSnoisy(:,:,1);
            Zmask = 1.*(obj.Ro>0.75*obj.Kotf ).*(obj.Ro<1.1*obj.Kotf );
            kAo = peakCCidx(obj,fSa1Tnoisy,fSa1Tnoisy,Zmask);
            kA = obj.IlluminationFreqTIRF(fSa1Tnoisy,fSa1Tnoisy,kAo);
            kmean = kA;
            kmag = sqrt(kmean*kmean');         
            %}
        end
        %-------------------------------------------------------------------------------------       
        
        
        function k2fa1 = IlluminationFreqTIRF(obj,fDo,fDp,kA)
            % preprocessing for noise suppression 
            %(this operations MUST be used during phase Estimation)
            fAo0 = fDo.*obj.G.*obj.OTFo.*obj.Zridge; 
            fAp0 = fDp.*obj.G.*obj.OTFo.*obj.Zridge;
            
            kv = kA(2) + 1i*kA(1);            
            Rp = abs(obj.Cv-kv);
            
            % Specify the search region for illumination freq peak
            Zmask = 1.*(Rp<0.02*obj.Kotf);
            k2fa = obj.peakCCidx(fAo0,fAp0,Zmask);
            
            %% subpixel approximation
            %----------------------------------
            % to avoid wrapping of frequencies while shifting
            if ( 2*obj.Kotf > obj.wo )
                t = 2*obj.w;
                fAo_temp = zeros(t,t);
                fAp_temp = zeros(t,t);
                fAo_temp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = fAo0;
                fAp_temp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = fAp0;
                clear fAo fAp
                fAo0 = fAo_temp;
                fAp0 = fAp_temp;
                clear fAo_temp fAp_temp
            end
            %----------------------------------
            % the following parameters are defined here to reduce the
            % amount of computation within the Ifreq2optF function            
            t = size(fAo0,1);
            u = linspace(0,t-1,t);
            v = linspace(0,t-1,t);
            [U,V] = meshgrid(u,v);            
            Ap0 = ifft2(fAp0);
            %----------------------------------
            opt = 1;
            Ifreq2opt0 = @(k2fa0)obj.Ifreq2opt(k2fa0,fAo0,Ap0,U,V,opt);
            options = optimset('LargeScale','off','Algorithm',...
                'active-set','MaxFunEvals',500,'MaxIter',500,'Display','notify');
            % options = optimset('LargeScale','off','Algorithm',...
            %             'active-set','MaxIter',200,'Display','iter');
            k2fa0 = k2fa;
            [k2fa1,fval] = fminunc(Ifreq2opt0,k2fa0,options);
            %k2fa1
            %k2a = sqrt(k2fa1*k2fa1')
        end
        %-------------------------------------------------------------------------------------
        
        
        function [CCop] = Ifreq2opt(~,k2fa,fAoT,Ap0,U,V,opt)
            
            t = size(fAoT,1);
            to = t/2;
            
            ApT = exp( +1i.*2*pi*( k2fa(2)/t.*(U-to)+k2fa(1)/t.*(V-to) ) ).*Ap0;
            fApT0 = fft2( ApT );
            
            mA = sum(sum( fAoT.*conj(fApT0) ));
            mA = mA./sum(sum( fApT0.*conj(fApT0) ));

            if opt>0
                CCop = -abs(mA);
            else
                CCop = angle(mA);
            end
            
        end
        %-------------------------------------------------------------------------------------
        
        function phase =  phasesF(obj)            
            phase = zeros(3,1);
            opt = 0;
            for i = 1:3
                fSa1Tnoisy = obj.fSnoisy(:,:,i);  
                fSa1Tnoisy = fSa1Tnoisy.*obj.G.*obj.OTFo.*obj.Zridge; % the operations here MUST be same as used in IlluminationFreqTIRF during kmean estimation
                %----------------------------------
                % to avoid wrapping of frequencies while shifting
                if ( 2*obj.Kotf > obj.wo )
                    t = 2*obj.w;
                    f_temp = zeros(t,t);
                    f_temp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = fSa1Tnoisy;
                    clear fSa1Tnoisy;
                    fSa1Tnoisy = f_temp;
                    clear f_temp
                end
                %----------------------------------
                if i == 1
                    t = size(fSa1Tnoisy,1);
                    u = linspace(0,t-1,t);
                    v = linspace(0,t-1,t);
                    [U,V] = meshgrid(u,v);
                end
                phase(i) = obj.Ifreq2opt(obj.kAmean,fSa1Tnoisy,ifft2(fSa1Tnoisy),U,V,opt);
            end
            
            %% for visual inspection
            %{
            phase*180/pi 
            
            kvec = exp(+1i*phase);
            u = [0:360]*pi/180;
            unitC = exp(1i.*u);
            figure;
            hold on
            plot(real(unitC),imag(unitC),'g-','LineWidth',2,'MarkerSize',6)
            plot(real(kvec),imag(kvec),'r*','LineWidth',2,'MarkerSize',6)
            for i = 1:3
                plot([0 real(kvec(i))],[0 imag(kvec(i))],'b--','LineWidth',1,'MarkerSize',6)
            end
            axis equal
            grid on
            box on
            title('Illumination Pattern Phase at the Image Center')
            kk
            %}
        end
        %-------------------------------------------------------------------------------------
        
        function Spattern = PatternCheckF(obj)
            k2a = obj.kAmean./obj.w;
            
            x = linspace(0,obj.w-1,obj.w);
            y = linspace(0,obj.w-1,obj.w);
            [X,Y] = meshgrid(x,y);
            
            ModFacEst = 1.0;
            Spattern = zeros(obj.w,obj.w,3);
            for i = 1:3
                Spattern(:,:,i) = 0.5 + 0.5*ModFacEst*cos(2*pi*(k2a(2).*(X-obj.wo)+k2a(1).*(Y-obj.wo))+obj.phaseA(i));
            end
            
            %% for visual verification
            %{
            id = 1;
            S1aTnoisy = real( ifft2(fftshift( obj.fSnoisy(:,:,id) )) );
            maxS = 0.6*double(max(S1aTnoisy(:)));
            Smix = S1aTnoisy;

            u = obj.w;
            pmix = 1;
            while mod(u,2)==0 && floor(obj.w/pmix)>32
                u = u/2;
                pmix = pmix*2;
            end
            
            sAo = Spattern(:,:,id);
            pp = obj.w/pmix;
            for u = 1:pmix
                for v = 1:pmix
                    if ( mod(u+v,2)==0 )
                        Smix((u-1)*pp+1:u*pp,(v-1)*pp+1:v*pp) = maxS.*sAo((u-1)*pp+1:u*pp,(v-1)*pp+1:v*pp);
                    end
                end
            end
            
            figure;
            imshow(Smix,[])
            % imshow(Smix(1:wo,1:wo),[])
            kk
            %}
            
        end
        %-------------------------------------------------------------------------------------
        
        function OBJparaA = OBJpowerPara(obj)

            LogF = log(abs(obj.fDo)) - log(obj.OTFo);

            %% object power parameters through optimization
            OBJparaOpt0 = @(OBJpara0)obj.OBJparaOpt(OBJpara0,LogF);
            options = optimset('LargeScale','off','Algorithm',...
                'active-set','MaxFunEvals',500,'MaxIter',500,'Display','notify');

            % obtaining crude initial guesses for Aobj and Bobj 
            Zm = (obj.Ro>0.3*obj.Kotf).*(obj.Ro<0.4*obj.Kotf);
            Bobj = sum(sum(LogF.*Zm))./sum(sum(Zm));
            Aobj = -0.5;
            OBJpara0 = [Aobj Bobj];

            % optimization step
            [OBJparaA,fval] = fminunc(OBJparaOpt0,OBJpara0,options);
            
            %% plot for cross-checking the result
            %{
            A = OBJparaA(1)
            B = OBJparaA(2)
            LogFe = A.*obj.Ro + B ;
            pp = 3;
            figure;
            hold on
            plot([0:obj.w-1]-obj.wo,LogF(obj.wo+pp,:),'k--','LineWidth',3,'MarkerSize',6)
            plot([0:obj.w-1]-obj.wo,LogFe(obj.wo+pp,:),'mo-','LineWidth',2,'MarkerSize',6)
            legend('LogF','LogFe')
            grid on
            box on


            OBJo = exp(LogFe);
            SIGp = OBJo.*obj.OTFo;
            pp = 3;
            figure;
            hold on
            plot([0:obj.w-1]-obj.wo,log(abs(obj.fDo(obj.wo+pp,:))),'k--','LineWidth',3,'MarkerSize',6)
            plot([0:obj.w-1]-obj.wo,log(abs(SIGp(obj.wo+pp,:))),'mo-','LineWidth',2,'MarkerSize',6)
            legend('acutal signal power','avg. signal power')
            grid on
            box on
            kk
            %}
        end
        %-------------------------------------------------------------------------------------
        
        function Esum = OBJparaOpt(obj,OBJpara0,LogF)
            Ro = obj.Ro;
            Ro(obj.wo+1,obj.wo+1) = 1; % to avoid nan

            % approximated signal power calculation
            A = OBJpara0(1);
            B = OBJpara0(2);
            LogFe = A.*Ro + B;

            % range of frequency over which SSE is computed
            %Zloop = obj.Zridge.*(Ro<0.85*obj.Kotf).*(Ro>0.12*obj.Kotf);
            Zloop = obj.Zridge.*(Ro<0.9*obj.kAmag).*(Ro>0.12*obj.Kotf);


            % SSE computation
            Error = LogF - LogFe;
            Esum = sum(sum((Error.^2./Ro).*Zloop));
        end
        %-------------------------------------------------------------------------------------
        
        function [fDof,NoisePower] = WoFilterCenterF(obj)            

            % OTF Power 
            OTFpower = obj.OTFo.*conj(obj.OTFo);

            % frequency beyond which NoisePower estimate to be computed
            NoiseFreq = obj.Kotf + 20;

            % NoisePower determination
            Zo = obj.Ro>NoiseFreq;
            nNoise = obj.fDo.*Zo;
            NoisePower = sum(sum( nNoise.*conj(nNoise) ))./sum(sum(Zo));

            % Object Power determination
            A = obj.OBJpara(1);
            B = obj.OBJpara(2);
            LogFe = A*obj.Ro + B ;
            OBJo = exp(LogFe);
            OBJpower = OBJo.^2 - 1.0*NoisePower;

            %% Wiener Filtering
            fDof = obj.fDo.*(conj(obj.OTFo)./NoisePower)./(OTFpower./NoisePower + obj.co./OBJpower);

            %% for cross-checking filtered estimate visually
            %{
            WFilter = (OTFpower./NoisePower)./(OTFpower./NoisePower + obj.co./OBJpower);
            fDo1 = fDof.*obj.OTFo;
            pp = 3;
            x = linspace(0,obj.w-1,obj.w);
            figure;
            hold on
            plot(x-obj.wo,log(abs(fDof(obj.wo+pp,:))),'go--','LineWidth',2,'MarkerSize',6)
            plot(x-obj.wo,log(abs(obj.fDo(obj.wo+pp,:))),'o--','LineWidth',2,'MarkerSize',6)
            plot(x-obj.wo,log(abs(fDo1(obj.wo+pp,:))),'r*--','LineWidth',2,'MarkerSize',4)
            plot(x-obj.wo,10*WFilter(obj.wo+pp,:),'k*--','LineWidth',2,'MarkerSize',4)
            title('WoFilter')
            legend('fDof','fDo','fDo1')
            grid on
            box on

            t = size(fDof,1);
            h = 30;
            SMao = real( ifft2(fftshift(obj.fDo)) );
            SMaof = real( ifft2(fftshift(fDof)) );
            SMao1 = real( ifft2(fftshift(fDo1)) );
            figure;
            imshow(SMao(h+1:t-h,h+1:t-h),[])
            colorbar
            title('raw')
            
            figure;
            imshow(SMaof(h+1:t-h,h+1:t-h),[])
            colorbar
            title('Wiener Filtered')
            
            figure;
            imshow(SMao1(h+1:t-h,h+1:t-h),[])
            colorbar
            title('Wiener Filtered (appodised)')
            %}
        end
        %-------------------------------------------------------------------------------------
        
        
        function [modFacA] = ModulationFactorF(obj)
            
            mf = zeros(3,1);

            f = 1*0.07;
            %Zo = obj.Zridge.*(obj.Ro<0.85*obj.Kotf).*(obj.Ro>f*obj.Kotf);
            Zo = obj.Zridge.*(obj.Ro<0.9*obj.kAmag).*(obj.Ro>f*obj.Kotf);
            
            Zq = 1-circshift(1-Zo,round(obj.kAmean)).*circshift(1-Zo,-round(obj.kAmean));
            Zq = Zq.*Zo;
            %{
            figure;
            surf(Zq,'EdgeColor','none')
            colormap jet 
            axis([0 obj.w-1 0 obj.w-1])
            title('Zq')
            kk
            %}

            for i = 1:3
                fS1aTnoisy = obj.fSnoisy(:,:,i);

                % simply taking ratio of 'real' past of C0 and deno would avoid the factor
                % 2 used below
                C0 = sum(sum( fS1aTnoisy.*conj(obj.fDo).*Zo ))...
                    + sum(sum( obj.fDo.*conj(fS1aTnoisy).*Zo ));
                deno = 2*sum(sum( obj.fDo.*conj(obj.fDo).*Zo ));
                C0 = C0/deno;
                
                fSuplex = fS1aTnoisy - C0*obj.fDo; 
                %{                
                figure;
                surf(log(abs(fSuplex)),'EdgeColor','none')
                colormap jet 
                axis([0 obj.w-1 0 obj.w-1])
                title('fSuplex')
                %kk
                %}
                
                I1a = obj.Spattern(:,:,i) - 0.5;
                DIoT = real( ifft2(fftshift(obj.fDof)) );
                Duplex = I1a.*DIoT;
                Duplex =  edgetaper(Duplex,obj.PSFe);
                fDuplex = fftshift(fft2(Duplex)).*obj.OTFo;
                %{                
                figure;
                surf(log(abs(fDuplex)),'EdgeColor','none')
                colormap jet 
                axis([0 obj.w-1 0 obj.w-1])
                title('fDuplex')
                kk
                %}

                
                Mm = sum(sum( fSuplex.*conj(fDuplex).*Zq ))...
                    + sum(sum( fDuplex.*conj(fSuplex).*Zq ));
                deno = 2*sum(sum( fDuplex .*conj(fDuplex).*Zq ));
                Mm = Mm/deno;
                mf(i) = Mm;
                mc(i) = C0;
                [i C0 Mm]
            end

            modFacA = 1*mean(mf(1:3));
        end
        %-------------------------------------------------------------------------------------
        
        function [fDp2,fDm2,npDp,npDm] = PCMfilteringF(obj)
                        
            % suppressing out-of-focus signal of off-center components using
            % a notch-filter (determined heuristically)
            fDp = obj.fDp.*obj.G;
            fDm = obj.fDm.*obj.G;

            % Object power parameters determination
            Aobj = obj.OBJpara(1);
            Bobj = obj.OBJpara(2);

            %% off-center frequency components <power> (default)
            kv = obj.kAmean(2) + 1i*obj.kAmean(1); % vector along illumination direction
            Rp = abs(obj.Cv-kv);
            Rm = abs(obj.Cv+kv);
            OBJp = exp(Aobj.*Rp + Bobj);
            OBJm = exp(Aobj.*Rm + Bobj);

            %% fixing the nan value in OBJp/OBJm            
            k3 = round(obj.kAmean);            
            OBJp(obj.wo+1+k3(1),obj.wo+1+k3(2)) = 0.25*OBJp(obj.wo+2+k3(1),obj.wo+1+k3(2))...
                + 0.25*OBJp(obj.wo+1+k3(1),obj.wo+2+k3(2))...
                + 0.25*OBJp(obj.wo+0+k3(1),obj.wo+1+k3(2))...
                + 0.25*OBJp(obj.wo+1+k3(1),obj.wo+0+k3(2));
            OBJm(obj.wo+1-k3(1),obj.wo+1-k3(2)) = 0.25*OBJm(obj.wo+2-k3(1),obj.wo+1-k3(2))...
                + 0.25*OBJm(obj.wo+1-k3(1),obj.wo+2-k3(2))...
                + 0.25*OBJm(obj.wo+0-k3(1),obj.wo+1-k3(2))...
                + 0.25*OBJm(obj.wo+1-k3(1),obj.wo+0-k3(2));

            %% Filtering side lobes (off-center frequency components)
            SFo = obj.modFac;
            [fDpf,npDp] = obj.WoFilterSideLobe(fDp,OBJm,SFo);
            [fDmf,npDm] = obj.WoFilterSideLobe(fDm,OBJp,SFo);
            
            %% doubling Fourier domain size if necessary
            DoubleMatSize = 0;
            if ( 2*obj.Kotf > obj.wo )
                DoubleMatSize = 1; % 1 for doubling fourier domain size, 0 for keeping it unchanged
            end
            if ( DoubleMatSize>0 )
                t = 2*obj.w;
                to = t/2;
                u = linspace(0,t-1,t);
                v = linspace(0,t-1,t);
                [U,V] = meshgrid(u,v);
                fDoTemp = zeros(t,t);
                fDpTemp = zeros(t,t);
                fDmTemp = zeros(t,t);
                fDoTemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = obj.fDof;
                fDpTemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = fDpf;
                fDmTemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = fDmf;
                clear fDpf fDmf 
                fDof = fDoTemp;
                fDpf = fDpTemp;
                fDmf = fDmTemp;
                clear fDoTemp fDpTemp fDmTemp 
            else
                t = obj.w;
                to = t/2;
                u = linspace(0,t-1,t);
                v = linspace(0,t-1,t);
                [U,V] = meshgrid(u,v);
                fDof = obj.fDof;
            end

            %% Shifting the off-center frequency components to their correct location
            fDp1 = fft2(ifft2(fDpf).*exp( +1i.*2*pi*(obj.kAmean(2)/t.*(U-to) + obj.kAmean(1)/t.*(V-to)) ));
            fDm1 = fft2(ifft2(fDmf).*exp( -1i.*2*pi*(obj.kAmean(2)/t.*(U-to) + obj.kAmean(1)/t.*(V-to)) ));
            %{
            figure;
            surf(log(abs(fDpf)),'EdgeColor','none')
            colormap jet
            figure;
            surf(log(abs(fDp1)),'EdgeColor','none')
            colormap jet
            kk
            %}

            %% Shift induced phase error correction
            Cv = (U-to) + 1i*(V-to);
            Ro = abs(Cv);
            Rp = abs(Cv-kv);
            % frequency range over which corrective phase is determined
            Zmask = (Ro < 0.8*obj.kAmag).*(Rp < 0.8*obj.kAmag);
            % corrective phase
            Angle0 = angle( sum(sum( fDof.*conj(fDp1).*Zmask )) );
            % phase correction
            fDp2 = exp(+1i*Angle0).*fDp1;
            fDm2 = exp(-1i*Angle0).*fDm1;

            %% for visual verification
            %{
            pp = 3;
            figure;
            hold on
            plot(u-to,angle(fDof(to+pp,:)).*180/pi,'o-','LineWidth',2,'MarkerSize',8)
            plot(u-to,angle(fDp1(to+pp,:)).*180/pi,'ro-','LineWidth',2,'MarkerSize',8)
            plot(u-to,angle(fDp2(to+pp,:)).*180/pi,'go--','LineWidth',2,'MarkerSize',6)
            grid on
            box on
            figure;
            hold on
            plot3(u-to,real(fDof(to+1,:)),imag(fDof(to+1,:)),'o-','LineWidth',2,'MarkerSize',8)
            plot3(u-to,real(fDp1(to+1,:)),imag(fDp1(to+1,:)),'ro-','LineWidth',2,'MarkerSize',8)
            plot3(u-to,real(fDp2(to+1,:)),imag(fDp2(to+1,:)),'go--','LineWidth',2,'MarkerSize',6)
            grid on
            box on

            ff1 = fDof.*conj(fDp1);
            ff2 = fDof.*conj(fDp2);
            figure;
            hold on
            plot(u-to,angle(ff1(to+pp,:)).*180/pi,'ro-','LineWidth',2,'MarkerSize',8)
            plot(u-to,angle(ff2(to+pp,:)).*180/pi,'go--','LineWidth',2,'MarkerSize',6)
            grid on
            box on
            kk
            %}            
                
        end        
        %-------------------------------------------------------------------------------------
        
        function [FiSMaof,NoisePower] = WoFilterSideLobe(obj,FiSMao,OBJsideP,SFo)

            OTFpower = obj.OTFo.*conj(obj.OTFo);

            % frequency beyond which NoisePower estimate to be computed
            NoiseFreq = obj.Kotf + 20;

            % NoisePower determination
            Zo = obj.Ro>NoiseFreq;
            nNoise = FiSMao.*Zo;
            NoisePower = sum(sum( nNoise.*conj(nNoise) ))./sum(sum(Zo));

            % Object Power determination
            OBJpower = OBJsideP.^2;

            %% Wiener Filtering
            FiSMaof = FiSMao.*(SFo.*conj(obj.OTFo)./NoisePower)./((SFo.^2).*OTFpower./NoisePower + obj.co./OBJpower);

            %% for cross-checking filtered estimate visually
            %{
            WFilter = (SFo.^2.*OTFpower./NoisePower)./((SFo.^2).*OTFpower./NoisePower + obj.co./OBJpower);
            FiSMao1 = FiSMaof.*obj.OTFo;            
            
            pp = 3;
            x = linspace(0,obj.w-1,obj.w);
            figure;
            hold on
            plot(x-obj.wo,log(abs(FiSMaof(obj.wo+pp,:))),'go--','LineWidth',2,'MarkerSize',6)
            plot(x-obj.wo,log(abs(FiSMao(obj.wo+pp,:))),'o--','LineWidth',2,'MarkerSize',6)
            plot(x-obj.wo,log(abs(FiSMao1(obj.wo+pp,:))),'r*--','LineWidth',2,'MarkerSize',4)
            plot(x-obj.wo,10*WFilter(obj.wo+pp,:),'k*--','LineWidth',2,'MarkerSize',4)
            title('WoFilter')
            legend('FiSMaof','FiSMao','FiSMao1')
            grid on
            box on
            %}

        end        
        %-------------------------------------------------------------------------------------
        
        
        function CheckMergingTripletsF(obj)         
            
            if ( 2*obj.Kotf > obj.wo )
                t = 2*obj.w;
                to = t/2;
                u = linspace(0,t-1,t);
                v = linspace(0,t-1,t);
                [U,V] = meshgrid(u,v);
                fDoTemp = zeros(t,t);
                OTFtemp = zeros(t,t);
                fDoTemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = obj.fDof;
                OTFtemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = obj.OTFo;
                fDof = fDoTemp;
                OTFo = OTFtemp;
                clear fDoTemp OTFtemp
            else
                t = obj.w;
                to = t/2;
                u = linspace(0,t-1,t);
                v = linspace(0,t-1,t);
                [U,V] = meshgrid(u,v);
                fDof = obj.fDof;
                OTFo = obj.OTFo;
            end
            
            [Fsum,Fperi] = obj.MergingTripletsF(fDof,OTFo); % fDof,OTFo may be of enlarged size
            
            
            pp = 3;
            figure;
            hold on
            % plot(u-to,log(abs(fDIo(to+pp,:))),'go--','LineWidth',2,'MarkerSize',6)
            plot(u-to,log(abs(Fsum(to+pp,:))),'o--','LineWidth',2,'MarkerSize',6)
            plot(u-to,log(abs(fDof(to+pp,:))),'r*--','LineWidth',2,'MarkerSize',4)
            plot(u-to,log(abs(obj.fDmf(to+pp,:))),'k*--','LineWidth',2,'MarkerSize',4)
            title('MergingTriplets')
            % legend('fDIo','Fsum','fDof','fDmf')
            grid on
            box on

            figure;
            hold on
            plot(u-to,log(abs(Fsum(to+pp,:))),'go-','LineWidth',2,'MarkerSize',6)
            plot(u-to,log(abs(Fperi(to+pp,:))),'o--','LineWidth',2,'MarkerSize',6)
            plot(u-to,log(abs(fDof(to+pp,:))),'r*--','LineWidth',2,'MarkerSize',4)
            plot(u-to,log(abs(obj.fDmf(to+pp,:))),'k*--','LineWidth',2,'MarkerSize',4)
            title('MergingTriplets')
            legend('Fsum','Fperi','fDof','fDmf')
            grid on
            box on

            figure;
            mesh(log(abs(Fperi)))
            colormap jet
            title('Fperi')

            figure;
            mesh(log(abs(Fsum)))
            colormap jet
            title('Fsum')

            Dof = real( ifft2(fftshift(fDof)) );
            figure;
            imshow(Dof,[])
            colorbar
            title('Dof')

            Dperi = real( ifft2(fftshift(Fperi)) );
            figure;
            imshow(Dperi,[])
            colorbar
            title('Dperi')

            Dsum = real( ifft2(fftshift(Fsum)) );
            figure;
            imshow(Dsum,[])
            colorbar
            title('Dsum')
                
        end        
        %-------------------------------------------------------------------------------------
        
        
        function [Fsum,Fperi] = MergingTripletsF(obj,fDof,OTFo) % fDof,OTFo may be of enlarged size
            
            [SIGao,SIGam2,SIGap2] = obj.TripletSNR0(OTFo);

            SIGap2 = obj.modFac*SIGap2;
            SIGam2 = obj.modFac*SIGam2;

            %% Generalized Wiener-Filter computation
            SNRao = SIGao.*conj(SIGao)./obj.npDo;
            SNRap = SIGap2.*conj(SIGap2)./obj.npDp;
            SNRam = SIGam2.*conj(SIGam2)./obj.npDm;

            ComDeno = 0.01 + ( SNRao + SNRap + SNRam );
            Fsum = fDof.*SNRao + obj.fDpf.*SNRap + obj.fDmf.*SNRam;
            Fsum = Fsum./ComDeno;

            ComPeri = 0.01 + ( SNRap + SNRam );
            Fperi = obj.fDpf.*SNRap + obj.fDmf.*SNRam;
            Fperi = Fperi./ComPeri;
            
        end        
        %-------------------------------------------------------------------------------------
        
        function [SIGao,SIGap2,SIGam2] = TripletSNR0(obj,OTFo)

            w = size(OTFo,1); % OTFo may be zero-paded, thus w != obj.w
            wo = w/2;
            x = linspace(0,w-1,w);
            y = linspace(0,w-1,w);
            [X,Y] = meshgrid(x,y);
            Cv = (X-wo) + 1i*(Y-wo);
            Ro = abs(Cv);

            % object spectrum parameters
            Aobj = obj.OBJpara(1);
            Bobj = obj.OBJpara(2);

            % object spectrums (default)
            kv = obj.kAmean(2) + 1i*obj.kAmean(1); % vector along illumination direction
            Rp = abs(Cv-kv);
            Rm = abs(Cv+kv);
            OBJo = exp(Aobj.*Ro + Bobj);
            OBJp = exp(Aobj.*Rp + Bobj);
            OBJm = exp(Aobj.*Rm + Bobj);

            OBJo(wo+1,wo+1) = 0.25*OBJo(wo+2,wo+1) + 0.25*OBJo(wo+1,wo+2)...
                + 0.25*OBJo(wo+0,wo+1) + 0.25*OBJo(wo+1,wo+0);

            k3 = round(obj.kAmean);
            OBJp(wo+1+k3(1),wo+1+k3(2)) = 0.25*OBJp(wo+2+k3(1),wo+1+k3(2))...
                + 0.25*OBJp(wo+1+k3(1),wo+2+k3(2))...
                + 0.25*OBJp(wo+0+k3(1),wo+1+k3(2))...
                + 0.25*OBJp(wo+1+k3(1),wo+0+k3(2));
            OBJm(wo+1-k3(1),wo+1-k3(2)) = 0.25*OBJm(wo+2-k3(1),wo+1-k3(2))...
                + 0.25*OBJm(wo+1-k3(1),wo+2-k3(2))...
                + 0.25*OBJm(wo+0-k3(1),wo+1-k3(2))...
                + 0.25*OBJm(wo+1-k3(1),wo+0-k3(2));

            % signal spectrums
            SIGao = OBJo.*OTFo;
            SIGap = OBJp.*OTFo;
            SIGam = OBJm.*OTFo;

            SIGap2 = circshift(SIGap,-k3);
            SIGam2 = circshift(SIGam,k3);

            %% for visual verification
            %{
            pp = 3;
            figure;
            hold on
            plot([0:w-1]-wo,log(abs(SIGap2(wo+pp,:))),'k--','LineWidth',3,'MarkerSize',6)
            plot([0:w-1]-wo,log(abs(obj.fDmf(wo+pp,:))),'mo-','LineWidth',2,'MarkerSize',6)
            grid on
            box on
            %}
        end
        %-------------------------------------------------------------------------------------
        
        function [fDof,OTFo] = OTFdoublingF(obj)   
            
            t = 2*obj.w;
            fDoTemp = zeros(t,t);
            OTFtemp = zeros(t,t);
            fDoTemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = obj.fDof;
            OTFtemp(obj.wo+1:obj.w+obj.wo,obj.wo+1:obj.w+obj.wo) = obj.OTFo;
            fDof = fDoTemp;
            OTFo = OTFtemp;
        end
        %-------------------------------------------------------------------------------------
        
        
        function [Fsum,ComDeno] = HeptaletComponentsF(obj,fDof,OTFo,object_tag) % fDof,OTFo may be of enlarged size
            
            if object_tag == 1
                [SIGao,SIGam2,SIGap2] = obj.TripletSNR0(OTFo);

                SIGap2 = obj.modFac*SIGap2;
                SIGam2 = obj.modFac*SIGam2;

                %% Generalized Wiener-Filter computation
                SNRao = SIGao.*conj(SIGao)./obj.npDo;
                SNRap = SIGap2.*conj(SIGap2)./obj.npDp;
                SNRam = SIGam2.*conj(SIGam2)./obj.npDm;

                ComDeno = ( SNRao + SNRap + SNRam );
                Fsum = fDof.*SNRao + obj.fDpf.*SNRap + obj.fDmf.*SNRam;
            else
                [~,SIGam2,SIGap2] = obj.TripletSNR0(OTFo);

                SIGap2 = obj.modFac*SIGap2;
                SIGam2 = obj.modFac*SIGam2;

                %% Generalized Wiener-Filter computation
                SNRap = SIGap2.*conj(SIGap2)./obj.npDp;
                SNRam = SIGam2.*conj(SIGam2)./obj.npDm;

                ComDeno = ( SNRap + SNRam );
                Fsum = obj.fDpf.*SNRap + obj.fDmf.*SNRam;
            end
                
            
        end
        %-------------------------------------------------------------------------------------
        
        
        
        
        
    end
    
end