function [FsumA] = ApodizationCosineF(Fsum,kmean,Kotf)

kA = kmean(1,:);
kB = kmean(2,:);
kC = kmean(3,:);
kAmag = sqrt(kA*kA');

%w = 700; %size(Fsum,1);
w = size(Fsum,1);
wo = w/2;
x = linspace(0,w-1,w);
y = linspace(0,w-1,w);
[X,Y] = meshgrid(x,y);
Co = (X-wo) + 1i*(Y-wo);
ka = kA(2) + 1i*kA(1);
kb = kB(2) + 1i*kB(1);
kc = kC(2) + 1i*kC(1);
Ro = abs(Co);
Rap = abs(Co-ka);
Ram = abs(Co+ka);
Rbp = abs(Co-kb);
Rbm = abs(Co+kb);
Rcp = abs(Co-kc);
Rcm = abs(Co+kc);

Zo = 1.*(Ro>Kotf);
Zap = 1.*(Rap>Kotf);
Zam = 1.*(Ram>Kotf);
Zbp = 1.*(Rbp>Kotf);
Zbm = 1.*(Rbm>Kotf);
Zcp = 1.*(Rcp>Kotf);
Zcm = 1.*(Rcm>Kotf);
Zmask = 1 - Zo.*Zap.*Zam.*Zbp.*Zbm.*Zcp.*Zcm;
%{
figure;
mesh(Zmask)
%}

argAp = abs(angle(Co.*conj(ka)));
argAm = abs(angle(Co.*conj(-ka)));
argBp = abs(angle(Co.*conj(kb)));
argBm = abs(angle(Co.*conj(-kb)));
argCp = abs(angle(Co.*conj(kc)));
argCm = abs(angle(Co.*conj(-kc)));
%{
figure;
mesh(argAp.*180/pi)
figure;
mesh(argAm.*180/pi)
%}

argAll = zeros(w,w,6);
argAll(:,:,1) = argAp;
argAll(:,:,2) = argAm;
argAll(:,:,3) = argBp;
argAll(:,:,4) = argBm;
argAll(:,:,5) = argCp;
argAll(:,:,6) = argCm;
argMin = min(argAll,[],3);
%{
figure;
mesh(argMin.*180/pi)
%}

temp = (kAmag*sin(argMin)).^2;
Rmax = kAmag*cos(argMin) + sqrt(Kotf^2 - temp);
%{
figure;
mesh(Rmax)
figure;
mesh(Ro./Rmax)
%}

ApoFunc = cos(pi/2.*(Ro./Rmax)).*Zmask;
%{
figure;
mesh(ApoFunc)
kk
%}

FsumA = Fsum.*ApoFunc;

