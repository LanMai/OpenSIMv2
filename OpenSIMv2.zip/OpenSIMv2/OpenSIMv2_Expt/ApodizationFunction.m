function [FsumA] = ApodizationFunction(Fsum,kmean,Kotf,Index)

t = size(Fsum,1);

OTFo_mask = OTFmaskShifted([0 0],Kotf,t);
OTFap_mask = OTFmaskShifted(kmean(1,:),Kotf,t);
OTFam_mask = OTFmaskShifted(-kmean(1,:),Kotf,t);
OTFbp_mask = OTFmaskShifted(kmean(2,:),Kotf,t);
OTFbm_mask = OTFmaskShifted(-kmean(2,:),Kotf,t);
OTFcp_mask = OTFmaskShifted(kmean(3,:),Kotf,t);
OTFcm_mask = OTFmaskShifted(-kmean(3,:),Kotf,t);
ApoMask = OTFo_mask.*OTFap_mask.*OTFam_mask.*OTFbp_mask.*OTFbm_mask.*OTFcp_mask.*OTFcm_mask;
clear OTFoz OTFo_mask OTFap_mask OTFam_mask OTFbp_mask OTFbm_mask 
%{
figure;
imshow(ApoMask,[ ])
%}

DistApoMask = bwdist(ApoMask);
maxApoMask = max(max(DistApoMask));
ApoFunc = double(DistApoMask./maxApoMask).^Index;
%{
figure;
imshow(DistApoMask,[ ])
figure;
mesh(double(ApoFunc))
%}

FsumA = Fsum.*ApoFunc;
clear ApoMask DistApoMask ApoFunc