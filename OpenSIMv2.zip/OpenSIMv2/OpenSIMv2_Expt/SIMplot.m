function SIMplot(Fsum,Fcent,OTFo,kmean,S1aTnoisy,h,saveFig)

t = size(OTFo,1);
w = size(S1aTnoisy,1);
if ( t > w )
    h = 2*h;
end

%% recontructed SIM images
Dcent = real( ifft2(fftshift(Fcent)) );
Dsum = real( ifft2(fftshift(Fsum)) );

t = size(OTFo,1);
%h = 1*30; % for removing the image edges
figure;
imshow(Dcent(h+1:t-h,h+1:t-h),[])
title('Wiener-Filtered wide-field')
figure;
imshow(Dsum(h+1:t-h,h+1:t-h),[])
title('default SIM image')


% appodizing the merged frequency components
Index = 0.4;
Kotf = OTFedgeF(OTFo);
[FsumA] = ApodizationFunction(Fsum,kmean,Kotf,Index);
[FsumAcosine] = ApodizationCosineF(Fsum,kmean,Kotf);
DsumA = real( ifft2(fftshift(FsumA)) );
DsumAcosine = real( ifft2(fftshift(FsumAcosine)) );

figure;
imshow(DsumA(h+1:t-h,h+1:t-h),[])
title('appodized SIM image')
figure;
imshow(DsumAcosine(h+1:t-h,h+1:t-h),[])
title('cosine-appodized SIM image')

if saveFig>0
    folderName = 'ReconstructedImages';
    mkdir(folderName)
    if size(S1aTnoisy,1)<t
        g = h/2;
        to = t/2;
        fname = strcat(folderName,'\raw_SIM_image.tif');
        imwrite(im2uint16(mat2gray(S1aTnoisy(g+1:to-g,g+1:to-g))),[fname],'tiff');
    else
        fname = strcat(folderName,'\raw_SIM_image.tif');
        imwrite(im2uint16(mat2gray(S1aTnoisy(h+1:t-h,h+1:t-h))),[fname],'tiff');
    end
    fname = strcat(folderName,'\Wiener_Filtered_wide_field.tif');
    imwrite(im2uint16(mat2gray(Dcent(h+1:t-h,h+1:t-h))),[fname],'tiff');
    
    fname = strcat(folderName,'\default_SIM_image.tif');
    imwrite(im2uint16(mat2gray(Dsum(h+1:t-h,h+1:t-h))),[fname],'tiff');
    
    fname = strcat(folderName,'\appodized_SIM_image.tif');
    imwrite(im2uint16(mat2gray(DsumA(h+1:t-h,h+1:t-h))),[fname],'tiff');
    
    fname = strcat(folderName,'\cosine_appodized_SIM_image.tif');
    imwrite(im2uint16(mat2gray(DsumAcosine(h+1:t-h,h+1:t-h))),[fname],'tiff');   
end

%% Frequency Plots
fS1aTnoisy = fftshift(fft2(S1aTnoisy));
to = t/2;
if ( t > w )
    fS1aTnoisy0 = zeros(t,t);
    fS1aTnoisy0(to-w/2+1:to+w/2,to-w/2+1:to+w/2) = fS1aTnoisy;
    clear fS1aTnoisy
    fS1aTnoisy = fS1aTnoisy0;
    clear fS1aTnoisy0;
end


p = 10;
minL1 = min(min( abs(fS1aTnoisy).^(1/p) ));
minL2 = min(min( abs(Fcent).^(1/p) ));
minL3 = min(min( abs(Fsum).^(1/p) ));
minL4 = min(min( abs(FsumA).^(1/p) ));
minL5 = min(min( abs(FsumAcosine).^(1/p) ));
maxL1 = max(max( abs(fS1aTnoisy).^(1/p) ));
maxL2 = max(max( abs(Fcent).^(1/p) ));
maxL3 = max(max( abs(Fsum).^(1/p) ));
maxL4 = max(max( abs(FsumA).^(1/p) ));
maxL5 = max(max( abs(FsumAcosine).^(1/p) ));
minL = min([minL1,minL2,minL3,minL4,minL5]);
maxL = max([maxL1,maxL2,maxL3,maxL4,maxL5]);

figure;
imshow(abs(fS1aTnoisy).^(1/p),[minL maxL])
title('fS1aTnoisy')

figure;
imshow(abs(Fcent).^(1/p),[minL maxL])
title('Weiner Filtered frequency')
figure;
imshow(abs(Fsum).^(1/p),[minL maxL])
title('SIM frequency')
figure;
imshow(abs(FsumA).^(1/p),[minL maxL])
title('appodized SIM frequency')
figure;
imshow(abs(FsumAcosine).^(1/p),[minL maxL])
title('cosine appodized SIM frequency')

if saveFig>0
    fname = strcat(folderName,'\raw_SIM_frequency.tif');
    imwrite(im2uint16(mat2gray(abs(fS1aTnoisy).^(1/p))),[fname],'tiff');   
    
    fname = strcat(folderName,'\Weiner_Filtered_frequency.tif');
    imwrite(im2uint16(mat2gray(abs(Fcent).^(1/p))),[fname],'tiff');   
    
    fname = strcat(folderName,'\default_SIM_frequency.tif');
    imwrite(im2uint16(mat2gray(abs(Fsum).^(1/p))),[fname],'tiff');   
    
    fname = strcat(folderName,'\appodized_SIM_frequency.tif');
    imwrite(im2uint16(mat2gray(abs(FsumA).^(1/p))),[fname],'tiff');   
    
    fname = strcat(folderName,'\cosine_appodized_SIM_frequency.tif');
    imwrite(im2uint16(mat2gray(abs(FsumA).^(1/p))),[fname],'tiff');   
end

