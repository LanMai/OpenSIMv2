%% convetional 9-frame SIM reconstruction algorithm
% Revised version of OpenSIM code posted earlier

clear variables; 
close all;
clc

w = 512; % image size
%% load specimen image
temp = imread('FractalNeuralNetwork.jpg');
temp = rgb2gray(temp);
DIo = double(temp(1:w,1:w));

%% Generation of the PSF with Besselj.
scale = 0.63; % used to adjust PSF/OTF width
[PSFo,OTFo] = PsfOtf(w,scale);

PSFe = fspecial('gaussian',30,3.0); % for edgetapering
%% Simulate SIM images
k2 = 90; % illumination frequency magnitude
alpha = pi/12;
ModFac = 0.9; % modulation factor
NoiseLevel = 10; % percentage noise level for generating gaussian noise
UsePSF = 0;
[Snoisy, DIoTnoisy, DIoT] = SIMimagesF(k2,DIo,PSFo,OTFo,ModFac,NoiseLevel,UsePSF,PSFe,alpha);



Kotf = OTFedgeF(OTFo); 
w = size(OTFo,1); % same as image size


%% initializing the s_class
for i = 1:3
    s_class{i} = single_orientation_class(Snoisy(:,:,(i-1)*3+1:i*3),OTFo,Kotf,PSFe); 
end 

for i = 1:3    
    %% Estimation of Illumination Frequency and Phases
    [s_class{i}.kAmean,s_class{i}.kAmag] =  s_class{i}.kmeanF();
    s_class{i}.phaseA =  s_class{i}.phasesF();
    
    %% Estimating illumination patterns
    s_class{i}.Spattern = s_class{i}.PatternCheckF();
    
    %% obtaining the noisy estimates of three frequency components
    [s_class{i}.fDo,s_class{i}.fDp,s_class{i}.fDm] = s_class{i}.PCMseparateF();
    
end

%% Averaging Central Frequency Component
fDo = zeros(w,w);
for i = 1:3
    fDo = fDo + s_class{i}.fDo;
end
%-----------------------------------------
s_class{1}.fDo = fDo/3;

%% Object Power Parameters
s_class{1}.OBJpara = s_class{1}.OBJpowerPara();

%% Wiener Filtering central frequency component
[s_class{1}.fDof, s_class{1}.npDo] = s_class{1}.WoFilterCenterF();


%% copying common information to other orientation_class
for i = 2:3
    s_class{i}.fDo = fDo/3;
    s_class{i}.OBJpara = s_class{1}.OBJpara;
    s_class{i}.fDof = s_class{1}.fDof;
    s_class{i}.npDo = s_class{1}.npDo;
end

for i = 1:3
    
    %% Determination of Modulation Factor
    s_class{i}.modFac = s_class{i}.ModulationFactorF();
    
    %% Wiener Filtering the noisy off-center frequency components
    [s_class{i}.fDpf,s_class{i}.fDmf,s_class{i}.npDp,s_class{i}.npDm] = s_class{i}.PCMfilteringF();
    
    %% for visual verification (super-resolution along individual illumination pattern orientation)
    %s_class{i}.CheckMergingTripletsF();
    
end

%% doubling Fourier domain size if necessary
if size(OTFo,1)<size(s_class{1}.fDpf,1)
    [fDof,OTFd] = s_class{1}.OTFdoublingF();
    DoubleMatSize = 1;
else
    fDof = s_class{1}.fDof;
    OTFd = OTFo;
    DoubleMatSize = 0;
end

%% merging all 7 frequency components using generalized Wiener Filter
for i = 1:3
    object_tag = i;
    [FsumTemp,ComDenoTemp] = s_class{i}.HeptaletComponentsF(fDof,OTFd,object_tag);

    if i==1
        Fsum = FsumTemp;
        ComDeno = 0.01 + ComDenoTemp;
    else
        Fsum = Fsum + FsumTemp;
        ComDeno = ComDeno + ComDenoTemp;
    end
end

Fsum = Fsum./ComDeno;
%{
figure;
surf(log(abs(Fsum)),'EdgeColor','none')
colormap jet
%}

kmean = [s_class{1}.kAmean; s_class{2}.kAmean; s_class{3}.kAmean];


% Plotting SIM results
saveFig = 1;
h = size(PSFe,1)/2;
SIMplot(Fsum,fDof,OTFo,kmean,Snoisy(:,:,1),h,saveFig);


